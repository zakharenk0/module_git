from datetime import date
from typing import List

from fastapi import FastAPI, HTTPException, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field


app = FastAPI(
    title="Warehouse Materials API",
    description=(
        "REST API автоматизированной системы складского учета "
        "материалов на предприятии транспорта."
    ),
    version="1.0.0",
)


class MaterialBase(BaseModel):
    """Общие поля материала согласно таблице 3.1 лабораторной работы №4."""

    name: str = Field(..., min_length=1, max_length=100,
                      description="Наименование материала")
    code: str = Field(..., min_length=1, max_length=30,
                      description="Код материала")
    quantity: float = Field(..., gt=0,
                             description="Количество материала")
    unit: str = Field(..., min_length=1, max_length=20,
                      description="Единица измерения")
    operation_date: date = Field(
        default_factory=date.today,
        description="Дата операции",
    )
    operation_type: str = Field(
        ...,
        min_length=1,
        max_length=50,
        description="Вид операции: поступление, выдача или перемещение",
    )


class MaterialCreate(MaterialBase):
    """Модель для создания материала."""


class Material(MaterialBase):
    """Модель материала, возвращаемая API."""

    id: int = Field(..., description="Уникальный идентификатор материала")


# Временное хранилище In-Memory. После перезапуска приложения данные сбрасываются.
materials: List[Material] = [
    Material(
        id=1,
        name="Подшипник",
        code="DET-001",
        quantity=25,
        unit="шт.",
        operation_date=date(2026, 11, 1),
        operation_type="Поступление",
    ),
    Material(
        id=2,
        name="Моторное масло",
        code="MAS-002",
        quantity=100,
        unit="л",
        operation_date=date(2026, 11, 2),
        operation_type="Поступление",
    ),
    Material(
        id=3,
        name="Тормозные колодки",
        code="DET-003",
        quantity=40,
        unit="шт.",
        operation_date=date(2026, 11, 3),
        operation_type="Выдача",
    ),
    Material(
        id=4,
        name="Фильтр воздушный",
        code="DET-004",
        quantity=15,
        unit="шт.",
        operation_date=date(2026, 11, 4),
        operation_type="Поступление",
    ),
    Material(
        id=5,
        name="Ремень приводной",
        code="DET-005",
        quantity=30,
        unit="шт.",
        operation_date=date(2026, 11, 5),
        operation_type="Перемещение",
    ),
]


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request, exc):
    """Возвращает HTTP 400 при ошибках проверки входных данных."""
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={"detail": exc.errors()},
    )


@app.get(
    "/api/v1/materials/",
    response_model=List[Material],
    summary="Получить список материалов",
    responses={200: {"description": "Список материалов получен"}},
)
def get_materials():
    """Возвращает все материалы, зарегистрированные на складе."""
    return materials


@app.get(
    "/api/v1/materials/{material_id}",
    response_model=Material,
    summary="Получить материал по ID",
    responses={
        200: {"description": "Материал найден"},
        404: {"description": "Материал не найден"},
    },
)
def get_material(material_id: int):
    """Возвращает подробную информацию об одном материале."""
    for material in materials:
        if material.id == material_id:
            return material

    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail="Материал с указанным ID не найден",
    )


@app.post(
    "/api/v1/materials/",
    response_model=Material,
    status_code=status.HTTP_201_CREATED,
    summary="Добавить новый материал",
    responses={
        201: {"description": "Материал успешно создан"},
        400: {"description": "Некорректные данные или такой код уже существует"},
    },
)
def create_material(material_data: MaterialCreate):
    """Создает новую запись о материале."""
    for material in materials:
        if material.code == material_data.code:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Материал с таким кодом уже существует",
            )

    new_id = max((material.id for material in materials), default=0) + 1
    new_material = Material(id=new_id, **material_data.model_dump())
    materials.append(new_material)
    return new_material


@app.delete(
    "/api/v1/materials/{material_id}",
    summary="Удалить материал",
    responses={
        200: {"description": "Материал успешно удален"},
        404: {"description": "Материал не найден"},
    },
)
def delete_material(material_id: int):
    """Удаляет материал по его идентификатору."""
    for index, material in enumerate(materials):
        if material.id == material_id:
            deleted_material = materials.pop(index)
            return {
                "message": "Материал успешно удален",
                "deleted_material": deleted_material,
            }

    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail="Материал с указанным ID не найден",
    )


@app.get("/", include_in_schema=False)
def root():
    """Корневая страница сервиса."""
    return {
        "message": "Warehouse Materials API is running",
        "documentation": "/docs",
    }
