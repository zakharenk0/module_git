# Warehouse Materials API

REST API для автоматизированной системы складского учета материалов на предприятии транспорта.

## Запуск локально

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --reload
```

Документация Swagger: http://127.0.0.1:8000/docs

## Запуск через Docker Compose

```powershell
docker compose up -d --build
```

Остановка:

```powershell
docker compose down
```

## Эндпоинты

- `GET /api/v1/materials/` — список материалов.
- `GET /api/v1/materials/{material_id}` — материал по ID.
- `POST /api/v1/materials/` — создание материала.
- `DELETE /api/v1/materials/{material_id}` — удаление материала.

Данные хранятся в памяти приложения и сбрасываются после перезапуска.
